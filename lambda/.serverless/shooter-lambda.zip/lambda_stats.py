from extensions import mongo
import json

def leaderboard_handler(event, context):
    # Obtener todos los jugadores
    players = list(mongo.db.Player.find({}, {"_id": 0}))
    leaderboard = []

    for p in players:
        kills = p["estadisticas"]["combate"]["kills"]
        deaths = p["estadisticas"]["combate"]["deaths"]
        hs = p["estadisticas"]["precision"]["headshots"]
        shots = p["estadisticas"]["precision"]["impactos"]

        leaderboard.append({
            "username": p["username"],
            "kills": kills,
            "deaths": deaths,
            "kd": round(kills / max(deaths, 1), 2),
            "hs_percent": round((hs / max(shots, 1)) * 100, 2)
        })

    return {
        "statusCode": 200,
        "body": json.dumps(leaderboard),
        "headers": {"Content-Type": "application/json"}
    }
